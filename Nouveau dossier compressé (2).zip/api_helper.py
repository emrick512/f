import requests

def fetch_product_info(barcode):
    """Queries Open Food Facts for product details"""
    # Using the production API as recommended for read operations
    url = f"https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
    
    # It is recommended to use a custom User-Agent
    headers = {'User-Agent': 'FridgeApp/1.0 (contact@example.com)'}
    
    try:
        response = requests.get(url, headers=headers, timeout=5)
        # FIXED: Correct attribute is status_code, not status_status
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == 1:
                p = data["product"]
                return {
                    "name": p.get("product_name", "Unknown Food"),
                    "brand": p.get("brands", "Generic"),
                    "category": p.get("categories", "Food").split(',')[0]
                }
    except Exception as e:
        print(f"API Error: {e}")
    return None