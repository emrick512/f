import json
import os

SETTINGS_FILE = "settings.json"

def save_email(email):
    with open(SETTINGS_FILE, "w") as f:
        json.dump({"default_email": email}, f)

def load_email():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            data = json.load(f)
            return data.get("default_email", "")
    return ""