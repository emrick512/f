import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), "fridge.db")
conn = sqlite3.connect(db_path, check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS fridge_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode TEXT UNIQUE,
    name TEXT,
    brand TEXT,
    quantity INTEGER DEFAULT 1,
    category TEXT
)
""")
conn.commit()

def add_or_update_item(barcode, name, brand, category):
    cursor.execute("SELECT quantity FROM fridge_items WHERE barcode=?", (barcode,))
    result = cursor.fetchone()
    if result:
        cursor.execute("UPDATE fridge_items SET quantity = quantity + 1 WHERE barcode=?", (barcode,))
    else:
        cursor.execute("INSERT INTO fridge_items (barcode, name, brand, quantity, category) VALUES (?, ?, ?, 1, ?)", 
                       (barcode, name, brand, category))
    conn.commit()

def adjust_quantity(barcode, amount):
    """Changes quantity by amount (e.g., -1 or +1)"""
    cursor.execute("SELECT quantity FROM fridge_items WHERE barcode=?", (barcode,))
    result = cursor.fetchone()
    if result:
        new_qty = max(0, result[0] + amount)
        cursor.execute("UPDATE fridge_items SET quantity = ? WHERE barcode=?", (new_qty, barcode))
        conn.commit()
        return new_qty
    return 0

def get_fridge_content():
    cursor.execute("SELECT * FROM fridge_items")
    return cursor.fetchall()