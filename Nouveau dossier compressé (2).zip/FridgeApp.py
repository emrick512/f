import customtkinter as ctk
import database
import api_helper
import settings_manager
import smtplib
from email.message import EmailMessage

class FridgeApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Smart Fridge Pro - Search & Scan")
        self.geometry("1100x800")
        
        self.shopping_cart = {} 
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # --- SIDEBAR NAV ---
        self.nav_frame = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.nav_frame.grid(row=0, column=0, sticky="nsew")
        ctk.CTkLabel(self.nav_frame, text="FRIDGE AI", font=("Arial", 20, "bold")).pack(pady=20)
        ctk.CTkButton(self.nav_frame, text="My Fridge Tank", command=self.show_fridge_page).pack(pady=10, padx=10)
        ctk.CTkButton(self.nav_frame, text="Scan to Buy", command=self.show_scan_buy_page, fg_color="#d97706").pack(pady=10, padx=10)

        self.main_view = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.main_view.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)

        self.show_fridge_page()

    def clear_main_view(self):
        for widget in self.main_view.winfo_children(): widget.destroy()

    # --- PAGE 1: FRIDGE TANK (With Search Bar) ---
    def show_fridge_page(self):
        self.clear_main_view()
        ctk.CTkLabel(self.main_view, text="Fridge Inventory", font=("Arial", 24)).pack(pady=10)
        
        # 1. SCAN TO ADD
        self.entry_add = ctk.CTkEntry(self.main_view, placeholder_text="SCAN BARCODE TO ADD ITEM...", height=45)
        self.entry_add.pack(fill="x", pady=5, padx=20)
        self.entry_add.bind("<Return>", lambda e: self.add_to_fridge())
        self.entry_add.focus()

        # 2. SEARCH BAR (New!)
        search_frame = ctk.CTkFrame(self.main_view, fg_color="transparent")
        search_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(search_frame, text="🔍 Search:").pack(side="left", padx=5)
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_fridge_ui())
        
        self.search_bar = ctk.CTkEntry(search_frame, placeholder_text="Type name, brand, or barcode...", textvariable=self.search_var)
        self.search_bar.pack(side="left", fill="x", expand=True, padx=5)

        self.fridge_scroll = ctk.CTkScrollableFrame(self.main_view, height=450)
        self.fridge_scroll.pack(fill="both", expand=True)
        self.refresh_fridge_ui()

    # --- LOGIC FOR SEARCH & REFRESH ---
    def refresh_fridge_ui(self):
        for widget in self.fridge_scroll.winfo_children(): widget.destroy()
        
        search_query = self.search_var.get().lower()
        items = database.get_fridge_content()
        
        for item in items:
            # item: (id, barcode, name, brand, quantity, category)
            name = str(item[2]).lower()
            brand = str(item[3]).lower()
            barcode = str(item[1]).lower()
            
            # Filtering Logic
            if search_query in name or search_query in brand or search_query in barcode:
                qty = item[4]
                f = ctk.CTkFrame(self.fridge_scroll, fg_color="#4a1a1a" if qty == 0 else "#2b2b2b")
                f.pack(fill="x", pady=5)
                
                ctk.CTkLabel(f, text=f"{item[2]} ({item[3]})", font=("Arial", 13)).pack(side="left", padx=10)
                
                # Controls
                ctk.CTkButton(f, text="+", width=30, command=lambda b=item[1]: self.update_fridge_qty(b, 1)).pack(side="right", padx=5)
                ctk.CTkLabel(f, text=str(qty), width=30, font=("Arial", 14, "bold")).pack(side="right", padx=5)
                ctk.CTkButton(f, text="-", width=30, command=lambda b=item[1], n=item[2]: self.update_fridge_qty(b, -1, n)).pack(side="right", padx=5)

    def update_fridge_qty(self, barcode, amt, name=None):
        new_qty = database.adjust_quantity(barcode, amt)
        if new_qty == 0 and name:
            self.shopping_cart[name] = self.shopping_cart.get(name, 0) + 1
        self.refresh_fridge_ui()

    def add_to_fridge(self):
        barcode = self.entry_add.get().strip()
        if barcode:
            info = api_helper.fetch_product_info(barcode)
            if info:
                database.add_or_update_item(barcode, info['name'], info['brand'], info['category'])
                self.refresh_fridge_ui()
        self.entry_add.delete(0, 'end')
        self.entry_add.focus()

    # --- PAGE 2: SCAN TO BUY ---
    def show_scan_buy_page(self):
        self.clear_main_view()
        ctk.CTkLabel(self.main_view, text="Shopping Cart", font=("Arial", 24)).pack(pady=10)
        
        self.entry_buy = ctk.CTkEntry(self.main_view, placeholder_text="SCAN ITEMS TO BUY...", height=50)
        self.entry_buy.pack(pady=10, padx=50, fill="x")
        self.entry_buy.bind("<Return>", lambda e: self.scan_to_cart())
        self.entry_buy.focus()

        self.cart_scroll = ctk.CTkScrollableFrame(self.main_view, height=350, label_text="Items Needed")
        self.cart_scroll.pack(pady=10, padx=50, fill="both", expand=True)
        self.refresh_cart_ui()

        control_frame = ctk.CTkFrame(self.main_view)
        control_frame.pack(pady=10, padx=50, fill="x")
        ctk.CTkButton(control_frame, text="🗑️ Clear", fg_color="#7a2a2a", command=self.clear_cart).pack(side="left", padx=10)
        
        self.email_target = ctk.CTkEntry(control_frame, placeholder_text="Email...")
        self.email_target.insert(0, settings_manager.load_email())
        self.email_target.pack(side="left", fill="x", expand=True, padx=10)
        ctk.CTkButton(control_frame, text="Send List", command=self.send_styled_email, fg_color="green").pack(side="right", padx=10)

    def scan_to_cart(self):
        barcode = self.entry_buy.get().strip()
        if barcode:
            info = api_helper.fetch_product_info(barcode)
            if info:
                name = f"{info['name']} ({info['brand']})"
                self.shopping_cart[name] = self.shopping_cart.get(name, 0) + 1
                self.refresh_cart_ui()
        self.entry_buy.delete(0, 'end')
        self.entry_buy.focus()

    def refresh_cart_ui(self):
        for widget in self.cart_scroll.winfo_children(): widget.destroy()
        for name, qty in self.shopping_cart.items():
            f = ctk.CTkFrame(self.cart_scroll, fg_color="#333")
            f.pack(fill="x", pady=2)
            ctk.CTkLabel(f, text=name).pack(side="left", padx=10)
            ctk.CTkButton(f, text="+", width=30, command=lambda n=name: self.update_cart_qty(n, 1)).pack(side="right", padx=5)
            ctk.CTkLabel(f, text=str(qty), width=30).pack(side="right", padx=5)
            ctk.CTkButton(f, text="-", width=30, command=lambda n=name: self.update_cart_qty(n, -1)).pack(side="right", padx=5)

    def update_cart_qty(self, name, amt):
        self.shopping_cart[name] = max(0, self.shopping_cart[name] + amt)
        if self.shopping_cart[name] == 0: del self.shopping_cart[name]
        self.refresh_cart_ui()

    def clear_cart(self):
        self.shopping_cart = {}
        self.refresh_cart_ui()

    def send_styled_email(self):
        receiver = self.email_target.get().strip()
        if not receiver or not self.shopping_cart: return
        settings_manager.save_email(receiver)
        
        MY_EMAIL = "emrick.tremblay956@gmail.com" 
        MY_PASSWORD = "cjsr urlp wfuj muce"
        
        msg = EmailMessage()
        msg['Subject'] = "🛒 Smart Fridge Shopping List"
        msg['From'] = MY_EMAIL
        msg['To'] = receiver
        items_html = "".join([f"<li>{qty}x {name}</li>" for name, qty in self.shopping_cart.items()])
        html = f"<html><body><h2>Shopping List:</h2><ul>{items_html}</ul></body></html>"
        msg.add_alternative(html, subtype='html')
        try:
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.starttls(); server.login(MY_EMAIL, MY_PASSWORD); server.send_message(msg)
            self.clear_cart()
        except Exception as e: print(f"Error: {e}")

if __name__ == "__main__":
    app = FridgeApp()
    app.mainloop()